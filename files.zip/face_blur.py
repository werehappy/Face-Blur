"""\nface_blur.py — Face Detection & Censoring GUI Application\nUses YOLOv8-face + OpenCV + Tkinter\n"""

import os
import threading
import multiprocessing
import tkinter as tk
from tkinter import filedialog, messagebox
import cv2
import numpy as np


# ══════════════════════════════════════════════════════════
#  GPU DETECTION & TORCH INSTALLER
# ══════════════════════════════════════════════════════════

def detect_gpu():
    """
    Returns dict with keys:
      has_nvidia  - bool, nvidia-smi found
      cuda_ver    - str like "12.1" or None
      torch_cuda  - bool, current torch has CUDA
      gpu_name    - str or None
    """
    import subprocess, shutil
    result = {"has_nvidia": False, "cuda_ver": None,
              "torch_cuda": False, "gpu_name": None}
    try:
        import torch
        result["torch_cuda"] = torch.cuda.is_available()
        if result["torch_cuda"]:
            result["gpu_name"] = torch.cuda.get_device_name(0)
    except Exception:
        pass

    # Check nvidia-smi even if torch says no CUDA
    smi = shutil.which("nvidia-smi")
    if smi:
        try:
            out = subprocess.check_output([smi], text=True, timeout=5)
            result["has_nvidia"] = True
            import re
            m = re.search(r"CUDA Version:\s*(\d+\.\d+)", out)
            if m:
                result["cuda_ver"] = m.group(1)
        except Exception:
            pass
    return result

def get_python_executable():
    """
    Get the real Python executable path.
    When running as a PyInstaller bundle, sys.executable is the .exe itself.
    We need the actual python.exe to run pip.
    """
    import sys
    # If frozen (PyInstaller exe), find python.exe next to the exe
    # or in a standard relative path
    if getattr(sys, "frozen", False):
        exe_dir = os.path.dirname(sys.executable)
        # Try common locations relative to the exe
        candidates = [
            os.path.join(exe_dir, "python.exe"),
            os.path.join(exe_dir, "_internal", "python.exe"),
        ]
        # Also check CONDA_PREFIX if set
        conda = os.environ.get("CONDA_PREFIX", "")
        if conda:
            candidates.insert(0, os.path.join(conda, "python.exe"))
        for c in candidates:
            if os.path.exists(c):
                return c
        # Last resort: find python.exe on PATH
        import shutil
        found = shutil.which("python")
        if found:
            return found
        return None
    else:
        return sys.executable

def install_torch_for_cuda(cuda_ver, log_fn=None):
    """Install correct torch build using the real Python executable."""
    import subprocess, sys

    ver = float(cuda_ver) if cuda_ver else 0
    if ver >= 12.1:
        index = "https://download.pytorch.org/whl/cu121"
        label = "CUDA 12.1+"
    elif ver >= 11.8:
        index = "https://download.pytorch.org/whl/cu118"
        label = "CUDA 11.8"
    else:
        index = "https://download.pytorch.org/whl/cpu"
        label = "CPU (CUDA too old)"

    if log_fn:
        log_fn("Installing torch for {}...\n".format(label), "accent")

    python_exe = get_python_executable()
    if python_exe is None:
        if log_fn:
            log_fn("[ERROR] Could not find Python executable to run pip.\n", "error")
        return False

    if log_fn:
        log_fn("  Using Python: {}\n".format(python_exe), "dim")

    cmd = [python_exe, "-m", "pip", "install",
           "torch", "torchvision",
           "--index-url", index, "--upgrade"]

    # CREATE_NO_WINDOW prevents a new console window on Windows
    kwargs = {}
    if sys.platform == "win32":
        kwargs["creationflags"] = 0x08000000  # CREATE_NO_WINDOW

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            **kwargs
        )
        for line in proc.stdout:
            if log_fn and line.strip():
                log_fn("  " + line.strip() + "\n", "dim")
        proc.wait()
        return proc.returncode == 0
    except Exception as e:
        if log_fn:
            log_fn("[ERROR] {}\n".format(e), "error")
        return False


# ══════════════════════════════════════════════════════════
#  YOLO
# ══════════════════════════════════════════════════════════

YOLO_MODELS = {
    "nano  (fastest)":   ("yolov8n-face.pt", "https://github.com/akanametov/yolo-face/releases/download/1.0.0/yolov8n-face.pt"),
    "medium (accurate)": ("yolov8m-face.pt", "https://github.com/akanametov/yolo-face/releases/download/1.0.0/yolov8m-face.pt"),
    "large (best)":      ("yolov8l-face.pt", "https://github.com/akanametov/yolo-face/releases/download/1.0.0/yolov8l-face.pt"),
}
_detector_cache = {}

def get_detector(model_key, log_fn=None):
    filename, url = YOLO_MODELS[model_key]
    if filename not in _detector_cache:
        from ultralytics import YOLO
        if not os.path.exists(filename):
            if log_fn:
                log_fn("  Downloading {} (first time only)...\n".format(filename), "warning")
            import urllib.request
            urllib.request.urlretrieve(url, filename)
            if log_fn:
                log_fn("  Download complete.\n", "success")
        model = YOLO(filename)
        _detector_cache[filename] = model
    return _detector_cache[filename]


# ══════════════════════════════════════════════════════════
#  CENSOR HELPERS
# ══════════════════════════════════════════════════════════

def blur_region(frame, x1, y1, x2, y2, intensity=51):
    roi = frame[y1:y2, x1:x2]
    if roi.size == 0:
        return frame
    k = intensity if intensity % 2 == 1 else intensity + 1
    frame[y1:y2, x1:x2] = cv2.GaussianBlur(roi, (k, k), 0)
    return frame

def pixelate_region(frame, x1, y1, x2, y2, block_size=15):
    roi = frame[y1:y2, x1:x2]
    h, w = roi.shape[:2]
    if h == 0 or w == 0:
        return frame
    small = cv2.resize(roi, (max(1, w // block_size), max(1, h // block_size)),
                       interpolation=cv2.INTER_LINEAR)
    frame[y1:y2, x1:x2] = cv2.resize(small, (w, h), interpolation=cv2.INTER_NEAREST)
    return frame

def black_bar_region(frame, x1, y1, x2, y2):
    frame[y1:y2, x1:x2] = 0
    return frame

def expand_bbox(x1, y1, x2, y2, padding, fw, fh):
    cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
    hw = (x2 - x1) / 2 * (1 + padding)
    hh = (y2 - y1) / 2 * (1 + padding)
    return max(0, int(cx-hw)), max(0, int(cy-hh)), min(fw, int(cx+hw)), min(fh, int(cy+hh))

def process_frame(frame, detector, mode, padding, intensity, block_size, confidence, debug):
    h, w = frame.shape[:2]
    results = detector(frame, conf=confidence, verbose=False, workers=0)
    n = 0
    for result in results:
        if result.boxes is None:
            continue
        for box in result.boxes:
            n += 1
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            x1, y1, x2, y2 = expand_bbox(x1, y1, x2, y2, padding, w, h)
            if   mode == "Blur":      frame = blur_region(frame, x1, y1, x2, y2, intensity)
            elif mode == "Pixelate":  frame = pixelate_region(frame, x1, y1, x2, y2, block_size)
            elif mode == "Black Bar": frame = black_bar_region(frame, x1, y1, x2, y2)
            if debug:
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 120), 2)
    return frame, n

def make_output_path(input_path, outdir):
    base   = os.path.splitext(os.path.basename(input_path))[0]
    folder = outdir if outdir else os.path.dirname(os.path.abspath(input_path))
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, base + "_blurred.mp4")


# ══════════════════════════════════════════════════════════
#  FFMPEG HELPER
# ══════════════════════════════════════════════════════════

def get_ffmpeg_path():
    """\n    Resolve ffmpeg.exe path:\n    1. Bundled inside PyInstaller exe (sys._MEIPASS)\n    2. Next to the exe / script\n    3. System PATH\n    """
    import sys
    ffmpeg_exe = "ffmpeg.exe"

    # PyInstaller bundle
    if hasattr(sys, "_MEIPASS"):
        bundled = os.path.join(sys._MEIPASS, ffmpeg_exe)
        if os.path.exists(bundled):
            return bundled

    # Next to exe/script
    base_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
    local = os.path.join(base_dir, ffmpeg_exe)
    if os.path.exists(local):
        return local

    # System PATH
    import shutil
    system = shutil.which("ffmpeg")
    if system:
        return system

    return None

def merge_audio(original_path, muted_path, output_path, ffmpeg_path, log_fn=None):
    """\n    Use ffmpeg to copy audio from original into the processed video.\n    Returns True on success, False on failure.\n    """
    import subprocess
    if log_fn:
        log_fn("  Merging audio...\n", "dim")
    cmd = [
        ffmpeg_path,
        "-y",                        # overwrite output
        "-i", muted_path,            # processed video (no audio)
        "-i", original_path,         # original (has audio)
        "-c:v", "copy",              # copy video stream as-is
        "-c:a", "aac",               # encode audio as AAC
        "-map", "0:v:0",             # video from processed file
        "-map", "1:a:0",             # audio from original file
        "-shortest",                 # end when shortest stream ends
        output_path
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if result.returncode == 0:
            if log_fn:
                log_fn("  Audio merged OK.\n", "dim")
            return True
        else:
            if log_fn:
                log_fn("  [WARN] ffmpeg error: {}\n".format(result.stderr[-200:]), "warning")
            return False
    except Exception as e:
        if log_fn:
            log_fn("  [WARN] ffmpeg failed: {}\n".format(e), "warning")
        return False


# ══════════════════════════════════════════════════════════
#  THEME
# ══════════════════════════════════════════════════════════

BG      = "#0f0f0f"
BG2     = "#1a1a1a"
BG3     = "#242424"
BORDER  = "#2e2e2e"
ACCENT  = "#00e5ff"
ACCENT2 = "#ff3c6e"
TEXT    = "#e8e8e8"
TDIM    = "#666666"
TMID    = "#999999"
SUCCESS = "#00c97a"
WARNING = "#ffb347"

FH = ("Courier New", 20, "bold")
FL = ("Courier New", 10, "bold")
FS = ("Courier New",  9)
FM = ("Courier New",  9)
FV = ("Courier New", 11, "bold")


# ══════════════════════════════════════════════════════════
#  MAIN APP
# ══════════════════════════════════════════════════════════

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("FACEBLUR")
        self.configure(bg=BG)
        self.geometry("960x780")
        self.minsize(900, 700)
        self._files       = []
        self._cancel_flag = threading.Event()
        self._outdir      = tk.StringVar()
        self._mode        = tk.StringVar(value="Blur")
        self._model_key   = tk.StringVar(value=list(YOLO_MODELS.keys())[0])
        self._conf        = tk.DoubleVar(value=0.40)
        self._pad         = tk.DoubleVar(value=0.20)
        self._blur_k      = tk.IntVar(value=51)
        self._pixel_sz    = tk.IntVar(value=15)
        self._debug       = tk.BooleanVar(value=False)
        self._build()

    # ── BUILD ─────────────────────────────────────────────

    def _build(self):
        # ── TOP BAR ──
        top = tk.Frame(self, bg=BG)
        top.pack(fill="x", padx=20, pady=(16, 0))
        tk.Label(top, text="FACEBLUR", bg=BG, fg=ACCENT, font=FH).pack(side="left")
        tk.Label(top, text="YOLOv8 face censoring", bg=BG, fg=TDIM, font=FS).pack(side="left", padx=12)
        tk.Label(top, text="made by werehappy", bg=BG, fg=TDIM, font=("Courier New", 8)).pack(side="left", padx=4)
        # GPU/CPU indicator (right side of top bar)
        self._gpu_info = detect_gpu()
        if self._gpu_info["torch_cuda"]:
            device_text  = "GPU: " + self._gpu_info["gpu_name"]
            device_color = SUCCESS
        elif self._gpu_info["has_nvidia"]:
            device_text  = "GPU available — not enabled"
            device_color = WARNING
        else:
            device_text  = "CPU only"
            device_color = WARNING
        self._device_lbl = tk.Label(top, text=device_text, bg=BG,
                                    fg=device_color, font=FL)
        self._device_lbl.pack(side="right")
        tk.Frame(self, bg=BORDER, height=1).pack(fill="x", padx=20, pady=(10, 0))

        # GPU banner removed - installer handles GPU/CPU version selection
        self._gpu_banner = None

        # ── MAIN AREA (fixed height, no expand) ──
        main = tk.Frame(self, bg=BG)
        main.pack(fill="x", padx=20, pady=10)

        left  = tk.Frame(main, bg=BG, width=370)
        left.pack(side="left", fill="y", padx=(0, 12))
        left.pack_propagate(False)

        right = tk.Frame(main, bg=BG)
        right.pack(side="left", fill="both", expand=True)

        # ── LEFT PANEL ──
        # file list card
        fc = tk.LabelFrame(left, text=" INPUT FILES ", bg=BG2, fg=TDIM,
                           font=FL, relief="flat", bd=1,
                           highlightbackground=BORDER, highlightthickness=1)
        fc.pack(fill="x", pady=(0, 8))

        self._count_lbl = tk.Label(fc, text="0 files", bg=BG2, fg=ACCENT, font=FS)
        self._count_lbl.pack(anchor="e", padx=8, pady=(4, 0))

        sb1 = tk.Scrollbar(fc, bg=BG2, troughcolor=BG3)
        sb1.pack(side="right", fill="y", padx=(0, 4), pady=4)
        self._lb = tk.Listbox(fc, bg=BG2, fg=TEXT, font=FS, height=8,
                              selectbackground=BG3, selectforeground=ACCENT,
                              relief="flat", bd=0, highlightthickness=0,
                              activestyle="none", yscrollcommand=sb1.set)
        self._lb.pack(fill="x", padx=(8, 0), pady=(0, 4))
        sb1.config(command=self._lb.yview)

        br = tk.Frame(fc, bg=BG2)
        br.pack(fill="x", padx=8, pady=(0, 8))
        self._btn(br, "+ ADD",   self._add_files,   accent=True).pack(side="left")
        self._btn(br, "REMOVE",  self._remove_sel).pack(side="left", padx=4)
        self._btn(br, "CLEAR",   self._clear_files, danger=True).pack(side="left")

        # output dir card
        oc = tk.LabelFrame(left, text=" OUTPUT FOLDER ", bg=BG2, fg=TDIM,
                           font=FL, relief="flat", bd=1,
                           highlightbackground=BORDER, highlightthickness=1)
        oc.pack(fill="x")
        er = tk.Frame(oc, bg=BG2)
        er.pack(fill="x", padx=8, pady=8)
        tk.Entry(er, textvariable=self._outdir, bg=BG3, fg=TEXT, font=FS,
                 relief="flat", bd=4, insertbackground=ACCENT
                 ).pack(side="left", fill="x", expand=True)
        self._btn(er, "BROWSE", self._pick_outdir).pack(side="left", padx=(4, 0))
        tk.Label(oc, text="Blank = same folder as source", bg=BG2, fg=TDIM,
                 font=FS).pack(anchor="w", padx=8, pady=(0, 8))

        # ── RIGHT PANEL ──
        # censor mode
        self._section(right, "CENSOR MODE")
        mr = tk.Frame(right, bg=BG2)
        mr.pack(fill="x", padx=8, pady=(0, 8))
        for m in ["Blur", "Pixelate", "Black Bar"]:
            tk.Radiobutton(mr, text=m, variable=self._mode, value=m,
                           bg=BG2, fg=TEXT, selectcolor=BG3,
                           activebackground=BG2, activeforeground=ACCENT,
                           font=FL, indicatoron=False,
                           padx=12, pady=5, relief="flat",
                           command=self._refresh_mode_btns).pack(side="left", padx=(0, 2))
        self._mode_btns = mr.winfo_children()
        self._refresh_mode_btns()

        # model
        self._section(right, "YOLO MODEL")
        mkr = tk.Frame(right, bg=BG2)
        mkr.pack(fill="x", padx=8, pady=(0, 4))
        for k in YOLO_MODELS.keys():
            tk.Radiobutton(mkr, text=k, variable=self._model_key, value=k,
                           bg=BG2, fg=TEXT, selectcolor=BG3,
                           activebackground=BG2, activeforeground=ACCENT,
                           font=FL, indicatoron=False,
                           padx=10, pady=4, relief="flat",
                           command=self._refresh_model_btns).pack(side="left", padx=(0, 2))
        self._model_btns = mkr.winfo_children()
        self._refresh_model_btns()
        tk.Label(right, text="Downloaded automatically on first use (~6-25 MB)",
                 bg=BG, fg=TDIM, font=FS).pack(anchor="w", padx=8, pady=(0, 6))

        # parameters
        self._section(right, "PARAMETERS")
        self._slider(right, "Confidence  ", self._conf,   0.10, 1.00, 0.05)
        self._slider(right, "Padding     ", self._pad,    0.00, 0.60, 0.05)
        self._slider(right, "Blur kernel ", self._blur_k, 11,   101,  2)
        self._slider(right, "Pixel size  ", self._pixel_sz, 5,  40,   1)

        # options
        self._section(right, "OPTIONS")
        tk.Checkbutton(right, text="Show debug boxes", variable=self._debug,
                       bg=BG, fg=TMID, font=FS, selectcolor=BG3,
                       activebackground=BG, activeforeground=ACCENT
                       ).pack(anchor="w", padx=8, pady=(0, 8))

        # progress
        self._section(right, "PROGRESS")
        self._status_lbl = tk.Label(right, text="Ready", bg=BG, fg=TDIM, font=FS, anchor="w")
        self._status_lbl.pack(fill="x", padx=8, pady=(0, 4))

        pb_frame = tk.Frame(right, bg=BG3, height=6)
        pb_frame.pack(fill="x", padx=8, pady=(0, 6))
        pb_frame.pack_propagate(False)
        self._pb_fill = tk.Frame(pb_frame, bg=ACCENT)
        self._pb_fill.place(x=0, y=0, width=0, height=6)
        self._pb_frame = pb_frame

        sr = tk.Frame(right, bg=BG)
        sr.pack(fill="x", padx=8, pady=(0, 8))
        self._lbl_file  = self._stat(sr, "FILE",  "-")
        self._lbl_frame = self._stat(sr, "FRAME", "-")
        self._lbl_faces = self._stat(sr, "FACES", "-")

        # action buttons
        ar = tk.Frame(right, bg=BG)
        ar.pack(fill="x", padx=8, pady=(4, 8))
        self._proc_btn   = self._btn(ar, "PROCESS", self._start, accent=True)
        self._cancel_btn = self._btn(ar, "CANCEL",  self._cancel, danger=True)
        self._proc_btn.pack(side="left")
        self._cancel_btn.pack(side="left", padx=8)
        self._set_running(False)

        # ── LOG (bottom, fixed height) ──
        tk.Frame(self, bg=BORDER, height=1).pack(fill="x", padx=20, pady=(4, 0))
        lh = tk.Frame(self, bg=BG)
        lh.pack(fill="x", padx=20, pady=(4, 2))
        tk.Label(lh, text="LOG", bg=BG, fg=TDIM, font=FL).pack(side="left")
        self._btn(lh, "CLEAR", self._clear_log).pack(side="right")

        log_frame = tk.Frame(self, bg=BG, height=160)
        log_frame.pack(fill="x", padx=20, pady=(0, 12))
        log_frame.pack_propagate(False)

        sb2 = tk.Scrollbar(log_frame, bg=BG2, troughcolor=BG3)
        sb2.pack(side="right", fill="y")
        self._log_text = tk.Text(log_frame, bg=BG, fg=TMID, font=FM,
                                 relief="flat", bd=0, wrap="word",
                                 yscrollcommand=sb2.set, state="disabled",
                                 selectbackground=BG3, insertbackground=ACCENT)
        self._log_text.pack(fill="both", expand=True)
        sb2.config(command=self._log_text.yview)

        self._log_text.tag_config("accent",  foreground=ACCENT)
        self._log_text.tag_config("success", foreground=SUCCESS)
        self._log_text.tag_config("warning", foreground=WARNING)
        self._log_text.tag_config("error",   foreground=ACCENT2)
        self._log_text.tag_config("dim",     foreground=TDIM)

        import sys
        self._write_log("FACEBLUR ready.  (YOLOv8-face)\n", "accent")
        self._write_log("Python: {}{}\n".format(
            sys.executable,
            " [bundled]" if getattr(sys, "frozen", False) else ""), "dim")
        gi = self._gpu_info
        if gi["torch_cuda"]:
            self._write_log("Device: GPU ({})\n".format(gi["gpu_name"]), "success")
        elif gi["has_nvidia"]:
            self._write_log(
                "Device: CPU  (Nvidia GPU found but torch lacks CUDA support)\n"
                "  -> Click ENABLE GPU above to fix this.\n", "warning")
        else:
            self._write_log(
                "Device: CPU only  (no Nvidia GPU detected)\n", "dim")

    # ── WIDGET HELPERS ────────────────────────────────────

    def _btn(self, parent, text, cmd, accent=False, danger=False):
        bg = ACCENT2 if danger else (ACCENT if accent else BG3)
        fg = BG if (accent or danger) else TEXT
        b = tk.Label(parent, text=text, bg=bg, fg=fg, font=FL,
                     cursor="hand2", padx=12, pady=6, relief="flat")
        b._bg = bg; b._accent = accent; b._danger = danger
        b.bind("<Button-1>", lambda e: cmd())
        b.bind("<Enter>",    lambda e: b.config(bg="#ff6b8a" if danger else ("#33ecff" if accent else "#333")))
        b.bind("<Leave>",    lambda e: b.config(bg=b._bg))
        return b

    def _section(self, parent, title):
        tk.Label(parent, text=title, bg=BG, fg=TDIM, font=FL
                 ).pack(anchor="w", padx=8, pady=(10, 4))

    def _slider(self, parent, label, var, from_, to, res):
        row = tk.Frame(parent, bg=BG)
        row.pack(fill="x", padx=8, pady=2)
        tk.Label(row, text=label, bg=BG, fg=TMID, font=FL, width=13, anchor="w").pack(side="left")
        val_lbl = tk.Label(row, bg=BG, fg=ACCENT, font=FV, width=6, anchor="e")
        val_lbl.pack(side="right")
        def update(*_):
            v = var.get()
            val_lbl.config(text="{:.2f}".format(v) if isinstance(v, float) and v % 1 != 0 else str(int(v)))
        tk.Scale(row, variable=var, from_=from_, to=to, resolution=res,
                 orient="horizontal", length=180, showvalue=False,
                 bg=BG, troughcolor=BG3, activebackground=ACCENT,
                 highlightthickness=0, bd=0, sliderlength=14,
                 command=update).pack(side="left", padx=4)
        update()

    def _stat(self, parent, label, value):
        f = tk.Frame(parent, bg=BG)
        f.pack(side="left", padx=(0, 20))
        tk.Label(f, text=label, bg=BG, fg=TDIM, font=FS).pack()
        lbl = tk.Label(f, text=value, bg=BG, fg=ACCENT, font=FV)
        lbl.pack()
        return lbl

    def _refresh_mode_btns(self):
        cur = self._mode.get()
        for b in self._mode_btns:
            active = (b["text"] == cur)
            b.config(bg=ACCENT if active else BG3, fg=BG if active else TDIM)

    def _refresh_model_btns(self):
        cur = self._model_key.get()
        for b in self._model_btns:
            active = (b["text"] == cur)
            b.config(bg=ACCENT if active else BG3, fg=BG if active else TDIM)

    # ── GPU ENABLE ────────────────────────────────────────

    def _enable_gpu(self):
        """Install CUDA torch in background, then prompt restart."""
        self._enable_gpu_btn.config(
            text="Installing...", bg=BG3, fg=TDIM, cursor="arrow")
        self._enable_gpu_btn.unbind("<Button-1>")
        gi = self._gpu_info

        def _do():
            success = install_torch_for_cuda(
                gi["cuda_ver"], log_fn=self._write_log)
            if success:
                # Force reload torch to check if CUDA is now available
                try:
                    import importlib, torch
                    importlib.reload(torch)
                    gpu_now = torch.cuda.is_available()
                    gpu_name = torch.cuda.get_device_name(0) if gpu_now else None
                except Exception:
                    gpu_now = False
                    gpu_name = None

                if gpu_now:
                    # GPU active immediately — update UI
                    self._write_log(
                        "\nGPU active: {}\n".format(gpu_name), "success")
                    self.after(0, lambda: self._device_lbl.config(
                        text="GPU: {}".format(gpu_name), fg=SUCCESS))
                    self.after(0, lambda: self._gpu_banner.pack_forget())
                else:
                    # Needs restart
                    self._write_log(
                        "\nInstalled! Restart FACEBLUR to activate GPU.\n",
                        "success")
                    self.after(0, lambda: messagebox.showinfo(
                        "Restart required",
                        "GPU support installed!\n\nPlease close and reopen FACEBLUR to activate it."))
                    self.after(0, lambda: self._enable_gpu_btn.config(
                        text="RESTART APP", bg=ACCENT, fg=BG, cursor="hand2"))
                    self.after(0, lambda: self._enable_gpu_btn.bind(
                        "<Button-1>", lambda e: self._restart_app()))
            else:
                self._write_log("\nGPU install failed. See log above.\n", "error")
                self.after(0, lambda: self._enable_gpu_btn.config(
                    text="FAILED - retry", bg=ACCENT2, fg=BG, cursor="hand2"))
                self.after(0, lambda: self._enable_gpu_btn.bind(
                    "<Button-1>", lambda e: self._enable_gpu()))

        threading.Thread(target=_do, daemon=True).start()

    def _restart_app(self):
        """Restart the application without opening a new console window."""
        import sys, subprocess
        kwargs = {}
        if sys.platform == "win32":
            kwargs["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
        subprocess.Popen([sys.executable] + sys.argv, **kwargs)
        self.destroy()

    # ── LOG ───────────────────────────────────────────────

    def _write_log(self, msg, tag=None):
        """Thread-safe log write."""
        def _do():
            self._log_text.config(state="normal")
            self._log_text.insert("end", msg, tag or ())
            self._log_text.see("end")
            self._log_text.config(state="disabled")
        self.after(0, _do)

    def _clear_log(self):
        self._log_text.config(state="normal")
        self._log_text.delete("1.0", "end")
        self._log_text.config(state="disabled")

    # ── PROGRESS ──────────────────────────────────────────

    def _set_progress(self, pct, status=None, file_n=None, frame_n=None, face_n=None):
        """Thread-safe progress update."""
        def _do():
            w = self._pb_frame.winfo_width()
            self._pb_fill.place(x=0, y=0, width=int(w * max(0.0, min(1.0, pct))), height=6)
            if status  is not None: self._status_lbl.config(text=status)
            if file_n  is not None: self._lbl_file.config(text=str(file_n))
            if frame_n is not None: self._lbl_frame.config(text=str(frame_n))
            if face_n  is not None: self._lbl_faces.config(text=str(face_n))
        self.after(0, _do)

    def _set_running(self, running):
        def _do():
            if running:
                self._proc_btn.config(state="disabled", fg=TDIM, bg=BG3, cursor="arrow")
                self._cancel_btn.config(fg=BG, bg=ACCENT2, cursor="hand2")
            else:
                self._proc_btn.config(state="normal", fg=BG, bg=ACCENT, cursor="hand2")
                self._cancel_btn.config(fg=TDIM, bg=BG3, cursor="arrow")
        self.after(0, _do)

    # ── FILE LIST ─────────────────────────────────────────

    def _add_files(self):
        paths = filedialog.askopenfilenames(
            title="Select video files",
            filetypes=[("Video files", "*.mp4 *.avi *.mov *.mkv *.wmv *.flv"),
                       ("All files", "*.*")])
        for p in paths:
            if p not in self._files:
                self._files.append(p)
                self._lb.insert("end", os.path.basename(p))
        self._count_lbl.config(text="{} file{}".format(
            len(self._files), "s" if len(self._files) != 1 else ""))

    def _remove_sel(self):
        for i in reversed(list(self._lb.curselection())):
            self._lb.delete(i); del self._files[i]
        self._count_lbl.config(text="{} file{}".format(
            len(self._files), "s" if len(self._files) != 1 else ""))

    def _clear_files(self):
        self._lb.delete(0, "end"); self._files.clear()
        self._count_lbl.config(text="0 files")

    def _pick_outdir(self):
        d = filedialog.askdirectory(title="Select output folder")
        if d: self._outdir.set(d)

    # ── PROCESSING ────────────────────────────────────────

    def _start(self):
        if not self._files:
            messagebox.showwarning("No files", "Add at least one video file first.")
            return
        self._cancel_flag.clear()
        self._clear_log()
        self._set_progress(0, status="Starting...")
        self._set_running(True)

        cfg = {
            "files":      list(self._files),
            "mode":       self._mode.get(),
            "model_key":  self._model_key.get(),
            "confidence": float(self._conf.get()),
            "padding":    float(self._pad.get()),
            "intensity":  int(self._blur_k.get()),
            "block_size": int(self._pixel_sz.get()),
            "debug":      self._debug.get(),
            "outdir":     self._outdir.get().strip() or None,
        }
        threading.Thread(target=self._run, args=(cfg,), daemon=True).start()

    def _cancel(self):
        self._cancel_flag.set()
        self._write_log("Cancelling...\n", "warning")

    def _run(self, cfg):
        try:
            self._run_inner(cfg)
        except Exception as e:
            import traceback
            self._write_log("\n[EXCEPTION]\n{}\n".format(traceback.format_exc()), "error")
        finally:
            self._set_running(False)

    def _run_inner(self, cfg):
        files = cfg["files"]
        n_files = len(files)

        self._write_log("Loading model: {}...\n".format(cfg["model_key"]), "accent")
        try:
            detector = get_detector(cfg["model_key"], log_fn=self._write_log)
        except Exception as e:
            self._write_log("[ERROR] {}\nRun: pip install ultralytics\n".format(e), "error")
            return
        self._write_log("Model OK. Processing {} file(s)...\n".format(n_files), "accent")

        for fi, path in enumerate(files, 1):
            if self._cancel_flag.is_set():
                break

            fname  = os.path.basename(path)
            outpath = make_output_path(path, cfg["outdir"])

            self._write_log("\n[{}/{}] {}\n".format(fi, n_files, fname), "accent")
            self._write_log("  -> {}\n".format(outpath), "dim")

            cap = cv2.VideoCapture(path)
            if not cap.isOpened():
                self._write_log("  [ERROR] Cannot open file\n", "error")
                continue

            fps    = cap.get(cv2.CAP_PROP_FPS) or 30.0
            W      = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            H      = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            total  = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

            self._write_log("  {}x{}  {:.1f}fps  {} frames\n".format(
                W, H, fps, total if total > 0 else "?"), "dim")

            if W == 0 or H == 0:
                self._write_log("  [ERROR] Bad dimensions\n", "error")
                cap.release(); continue

            # Write to a temp muted file first, then merge audio with ffmpeg
            tmp_path = outpath + ".tmp_muted.mp4"
            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            writer = cv2.VideoWriter(tmp_path, fourcc, fps, (W, H))
            if not writer.isOpened():
                self._write_log("  [ERROR] Cannot create output file\n", "error")
                cap.release(); continue

            frame_n = 0
            faces_n = 0

            while not self._cancel_flag.is_set():
                ok, frame = cap.read()
                if not ok:
                    break
                frame, nf = process_frame(
                    frame, detector,
                    cfg["mode"], cfg["padding"], cfg["intensity"],
                    cfg["block_size"], cfg["confidence"], cfg["debug"])
                writer.write(frame)
                frame_n += 1
                faces_n += nf

                if frame_n % 5 == 0:
                    pct = (frame_n / total) if total > 0 else 0.5
                    self._set_progress(
                        pct,
                        status="Processing frame {}{} — {} face(s)".format(
                            frame_n,
                            "/{}".format(total) if total > 0 else "",
                            nf),
                        file_n="{}/{}".format(fi, n_files),
                        frame_n=frame_n,
                        face_n=faces_n)

            cap.release()
            writer.release()

            if self._cancel_flag.is_set():
                self._write_log("  Cancelled.\n", "warning")
                if os.path.exists(tmp_path): os.remove(tmp_path)
            elif frame_n == 0:
                self._write_log("  [ERROR] 0 frames read!\n", "error")
                if os.path.exists(tmp_path): os.remove(tmp_path)
            elif not os.path.exists(tmp_path) or os.path.getsize(tmp_path) == 0:
                self._write_log("  [ERROR] Output empty/missing\n", "error")
            else:
                # Try to merge audio using bundled ffmpeg
                ffmpeg = get_ffmpeg_path()
                if ffmpeg:
                    merged = merge_audio(path, tmp_path, outpath, ffmpeg,
                                         log_fn=self._write_log)
                    if os.path.exists(tmp_path): os.remove(tmp_path)
                    if not merged:
                        # ffmpeg failed — fall back to muted file
                        self._write_log("  Falling back to muted output.\n", "warning")
                        os.rename(tmp_path if os.path.exists(tmp_path) else tmp_path, outpath)
                else:
                    # No ffmpeg — rename temp to final (no audio)
                    self._write_log("  [WARN] ffmpeg not found — output has no audio.\n", "warning")
                    if os.path.exists(outpath): os.remove(outpath)
                    os.rename(tmp_path, outpath)

                if os.path.exists(outpath):
                    mb = os.path.getsize(outpath) / 1048576
                    self._write_log(
                        "  Done. {} frames, {} faces, {:.1f} MB\n".format(
                            frame_n, faces_n, mb), "success")
                    self._set_progress(1.0, status="Done: {}".format(fname),
                                       file_n="{}/{}".format(fi, n_files),
                                       frame_n=frame_n, face_n=faces_n)

        if not self._cancel_flag.is_set():
            self._write_log("\nAll files finished.\n", "success")
        self._set_progress(0 if self._cancel_flag.is_set() else 1.0,
                           status="Cancelled." if self._cancel_flag.is_set() else "All done!")


# ══════════════════════════════════════════════════════════

if __name__ == "__main__":
    multiprocessing.freeze_support()   # required for PyInstaller on Windows
    app = App()
    app.mainloop()
