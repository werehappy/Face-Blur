; FACEBLUR Inno Setup Script
; Detects GPU during install and installs correct version

#define AppName "FACEBLUR"
#define AppVersion "1.0"
#define AppPublisher "werehappy"
#define AppExeName "FACEBLUR.exe"

[Setup]
AppId={{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
OutputDir=installer_output
OutputBaseFilename=FACEBLUR_Setup
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"

[Files]
; The installer script will choose which exe to install based on GPU detection
; Both CPU and GPU versions are included
Source: "dist\FACEBLUR_CPU.exe"; DestDir: "{app}"; DestName: "FACEBLUR.exe"; Flags: ignoreversion; Check: not HasNvidiaGPU
Source: "dist\FACEBLUR_GPU.exe"; DestDir: "{app}"; DestName: "FACEBLUR.exe"; Flags: ignoreversion; Check: HasNvidiaGPU
Source: "ffmpeg.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExeName}"
Name: "{group}\Uninstall {#AppName}"; Filename: "{uninstallexe}"
Name: "{commondesktop}\{#AppName}"; Filename: "{app}\{#AppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExeName}"; Description: "Launch {#AppName}"; Flags: nowait postinstall skipifsilent

[Code]
var
  GPUDetected: Boolean;
  GPUChecked: Boolean;

function HasNvidiaGPU: Boolean;
var
  ResultCode: Integer;
  TempFile: String;
  Output: TArrayOfString;
begin
  if GPUChecked then
  begin
    Result := GPUDetected;
    Exit;
  end;

  GPUChecked := True;
  GPUDetected := False;
  TempFile := ExpandConstant('{tmp}\gpu_check.txt');

  // Run nvidia-smi and capture output
  if Exec('cmd.exe', '/c nvidia-smi > "' + TempFile + '" 2>&1', '',
          SW_HIDE, ewWaitUntilTerminated, ResultCode) then
  begin
    if ResultCode = 0 then
    begin
      if LoadStringsFromFile(TempFile, Output) then
      begin
        if GetArrayLength(Output) > 0 then
          GPUDetected := True;
      end;
    end;
  end;

  Result := GPUDetected;
end;

function NextButtonClick(CurPageID: Integer): Boolean;
begin
  Result := True;
  // On the ready page, show which version will be installed
  if CurPageID = wpReady then
  begin
    if HasNvidiaGPU then
      Log('GPU version will be installed')
    else
      Log('CPU version will be installed');
  end;
end;

procedure InitializeWizard;
begin
  GPUChecked := False;
  GPUDetected := False;
end;

function UpdateReadyMemo(Space, NewLine, MemoUserInfoInfo, MemoDirInfo,
  MemoTypeInfo, MemoComponentsInfo, MemoGroupInfo, MemoTasksInfo: String): String;
var
  S: String;
begin
  S := '';
  if MemoDirInfo <> '' then S := S + MemoDirInfo + NewLine + NewLine;
  if MemoGroupInfo <> '' then S := S + MemoGroupInfo + NewLine + NewLine;
  if MemoTasksInfo <> '' then S := S + MemoTasksInfo + NewLine + NewLine;

  if HasNvidiaGPU then
    S := S + 'GPU Version: Nvidia GPU detected - GPU-accelerated version will be installed.' + NewLine
  else
    S := S + 'CPU Version: No Nvidia GPU detected - CPU version will be installed.' + NewLine;

  Result := S;
end;
