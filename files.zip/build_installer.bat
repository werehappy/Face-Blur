@echo off
setlocal enabledelayedexpansion

echo.
echo ==================================================
echo   FACEBLUR  --  Build Installer
echo ==================================================
echo.

set ENV_NAME=faceblur
set SCRIPT=face_blur.py
set FFMPEG_EXE=ffmpeg.exe
set ISCC="C:\Program Files (x86)\Inno Setup 6\ISCC.exe"

:: ── Find conda ────────────────────────────────────────────
set CONDA_ROOT=%USERPROFILE%\anaconda3
if not exist "%CONDA_ROOT%\Scripts\activate.bat" set CONDA_ROOT=%USERPROFILE%\miniconda3
if not exist "%CONDA_ROOT%\Scripts\activate.bat" set CONDA_ROOT=C:\ProgramData\anaconda3
if not exist "%CONDA_ROOT%\Scripts\activate.bat" set CONDA_ROOT=C:\ProgramData\miniconda3
if not exist "%CONDA_ROOT%\Scripts\activate.bat" (
    echo [ERROR] Cannot find conda.
    pause & exit /b 1
)
call "%CONDA_ROOT%\Scripts\activate.bat" "%CONDA_ROOT%"
call conda activate %ENV_NAME%
if errorlevel 1 ( echo [ERROR] Cannot activate %ENV_NAME%. & pause & exit /b 1 )
echo       Using env: %CONDA_PREFIX%

cd /d "%~dp0"

:: ── Check ffmpeg ──────────────────────────────────────────
if not exist "%FFMPEG_EXE%" (
    echo [ERROR] ffmpeg.exe not found. Run build.bat first.
    pause & exit /b 1
)

:: ── Step 1: Build CPU version ─────────────────────────────
echo.
echo [1/4] Installing CPU-only torch...
"%CONDA_PREFIX%\Scripts\pip.exe" install torch torchvision --index-url https://download.pytorch.org/whl/cpu --upgrade -q
if errorlevel 1 ( echo [ERROR] CPU torch install failed. & pause & exit /b 1 )

echo [1/4] Building CPU exe...
taskkill /f /im FACEBLUR_CPU.exe >nul 2>&1
if exist "%~dp0dist\FACEBLUR_CPU.exe" del /f /q "%~dp0dist\FACEBLUR_CPU.exe"
"%CONDA_PREFIX%\Scripts\pyinstaller.exe" --onefile --noconsole --clean --collect-data ultralytics --hidden-import ultralytics --add-data "ffmpeg.exe;." --name FACEBLUR_CPU %SCRIPT%
if errorlevel 1 ( echo [ERROR] CPU build failed. & pause & exit /b 1 )
echo       CPU exe ready: dist\FACEBLUR_CPU.exe

:: ── Step 2: Build GPU version ─────────────────────────────
echo.
echo [2/4] Detecting GPU for torch CUDA version...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_torch.ps1" "%CONDA_PREFIX%\Scripts\pip.exe"
if errorlevel 1 ( echo [ERROR] GPU torch install failed. & pause & exit /b 1 )

echo [2/4] Building GPU exe...
taskkill /f /im FACEBLUR_GPU.exe >nul 2>&1
if exist "%~dp0dist\FACEBLUR_GPU.exe" del /f /q "%~dp0dist\FACEBLUR_GPU.exe"
"%CONDA_PREFIX%\Scripts\pyinstaller.exe" --onefile --noconsole --clean --collect-data ultralytics --hidden-import ultralytics --add-data "ffmpeg.exe;." --name FACEBLUR_GPU %SCRIPT%
if errorlevel 1 ( echo [ERROR] GPU build failed. & pause & exit /b 1 )
echo       GPU exe ready: dist\FACEBLUR_GPU.exe

:: ── Step 3: Download ffmpeg if needed ─────────────────────
echo.
echo [3/4] Checking ffmpeg...
if not exist "%~dp0%FFMPEG_EXE%" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0download_ffmpeg.ps1"
    if errorlevel 1 ( echo [ERROR] ffmpeg download failed. & pause & exit /b 1 )
)
echo       ffmpeg OK.

:: ── Step 4: Compile Inno Setup installer ──────────────────
echo.
echo [4/4] Compiling installer with Inno Setup...
if not exist %ISCC% (
    echo [ERROR] Inno Setup not found at %ISCC%
    echo         Download from: https://jrsoftware.org/isdl.php
    pause & exit /b 1
)

if not exist "%~dp0installer_output" mkdir "%~dp0installer_output"
%ISCC% "%~dp0installer.iss"
if errorlevel 1 ( echo [ERROR] Inno Setup compile failed. & pause & exit /b 1 )

echo.
echo ==================================================
echo   Done!
echo   Installer: %~dp0installer_output\FACEBLUR_Setup.exe
echo   Distribute this single file to your users.
echo ==================================================
echo.
pause
